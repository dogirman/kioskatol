package com.example.kioskatol

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

class ChromeBlockerService : AccessibilityService() {

    private val allowedChromeActivities = setOf(
        "com.android.chrome.downloads.DownloadManagerUiActivity",
        "com.android.chrome.downloads.DownloadActivity"
    )

    private var chromeStartedAt: Long = 0
    private val gracePeriod = 10_000L // 10 секунд

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val pkg = event.packageName?.toString() ?: return
        val cls = event.className?.toString() ?: return

        // Chrome открыт
        if (pkg == "com.android.chrome") {

            // Если Chrome запущен впервые — фиксируем время входа
            if (chromeStartedAt == 0L) {
                chromeStartedAt = System.currentTimeMillis()
            }

            val now = System.currentTimeMillis()

            // 10-секундное окно для загрузок
            if (now - chromeStartedAt < gracePeriod) {
                return
            }

            // После 10 секунд — проверяем, в каком окне Chrome
            if (!allowedChromeActivities.contains(cls)) {
                // Неправильное окно → отправляем в киоск
                chromeStartedAt = 0L
                val intent = Intent(this, MainActivity::class.java)
                intent.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP
                )
                startActivity(intent)
            }
        } else {
            // Chrome закрылся → сбрасываем таймер
            chromeStartedAt = 0L
        }
    }

    override fun onInterrupt() {}
}

