package com.example.kioskatol

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.content.Intent
import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.util.Log

class DownloadGuardAccessibilityService : AccessibilityService() {

    private val TAG = "DownloadGuardAS"

    // Пакеты, которые хотим мониторить (добавь/убери по необходимости)
    private val monitoredPackages = setOf(
        "com.android.chrome",
        "com.android.providers.downloads.ui",
        "com.android.providers.downloads",
        "com.android.browser"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val pkg = event.packageName?.toString() ?: return
        if (!monitoredPackages.contains(pkg)) return

        val eventType = event.eventType
        val className = event.className?.toString() ?: ""
        val eventText = (event.text?.joinToString(" ") ?: "").lowercase()

        Log.d(TAG, "evt pkg=$pkg type=$eventType class=$className text='$eventText'")

        try {
            // Быстрая эвристика: если имя класса или текст указывает на "Download(s)" / "Загрузка" / "Cancel" и т.п.
            if (className.contains("download", ignoreCase = true) ||
                className.contains("downloads", ignoreCase = true) ||
                eventText.contains("download") ||
                eventText.contains("загруз") ||   // русская форма "загрузка", "загрузки"
                eventText.contains("cancel") ||
                eventText.contains("отмена") ||
                eventText.contains("save") ||
                eventText.contains("скач") // "скачать", "скачивание"
            ) {
                forceReturnToKiosk(pkg)
                return
            }

            // дополнительно: при кликах/изменении окна — агрессивно возвращаем
            if (eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
                eventType == AccessibilityEvent.TYPE_VIEW_CLICKED
            ) {
                // если окно выглядит как диалог/загрузки — возврат
                if (className.isNotEmpty() && className.lowercase().contains("activity")) {
                    forceReturnToKiosk(pkg)
                    return
                }
            }
        } catch (ex: Exception) {
            Log.w(TAG, "onAccessibilityEvent error: ${ex.message}")
        }
    }

    override fun onInterrupt() {
        // ничего
    }

    /**
     * Попытка вернуть пользователя на Home / в киоск.
     * 1) performGlobalAction(GLOBAL_ACTION_HOME)
     * 2) запасной вариант: убить фоновые процессы пакета
     */
    private fun forceReturnToKiosk(pkg: String) {
        try {
            Log.i(TAG, "Detected downloads UI for $pkg — going HOME")
            // Сначала HOME (должен вернуть в лаунчер/киоск)
            performGlobalAction(GLOBAL_ACTION_HOME)
        } catch (e: Exception) {
            Log.w(TAG, "performGlobalAction HOME failed: ${e.message}")
        }

        // Немного задержки не нужен — HOME обычно срабатывает мгновенно.
        // Но на всякий случай — попытка остановить процесс как fallback.
        try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            am.killBackgroundProcesses(pkg)
            Log.i(TAG, "killBackgroundProcesses($pkg) called")
        } catch (e: Exception) {
            Log.w(TAG, "killBackgroundProcesses failed: ${e.message}")
        }

        // Дополнительно: можно запустить наше MainActivity (если нужно гарантированно)
        try {
            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
        } catch (e: Exception) {
            Log.w(TAG, "startActivity(MainActivity) failed: ${e.message}")
        }
    }
}
